class Foo { // Fooクラス
	public Foo() { // コンストラクタ
	}
}
