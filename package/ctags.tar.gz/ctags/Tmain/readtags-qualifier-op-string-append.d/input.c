struct abpcx {
	int p;
};

struct abpcy {
	int p;
};

struct abpcz {
	int p;
};
