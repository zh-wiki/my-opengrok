/*
 * ctags --fields='*' --kinds-C='*' -o c.tags base.c
 */
int
main(int argc, char ** argv)
{
	int r = argc + 1;
	return r;
}
